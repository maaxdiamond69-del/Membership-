import requests
import asyncio
import aiohttp
import binascii
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from google.protobuf.json_format import MessageToJson
from urllib.parse import urlparse, parse_qs
import my_pb2
import output_pb2
import like_pb2
import like_count_pb2
import uid_generator_pb2
import json
import warnings
from concurrent.futures import ThreadPoolExecutor

warnings.simplefilter('ignore', requests.packages.urllib3.exceptions.InsecureRequestWarning)

AES_KEY = b'Yg&tc%DEuh6%Zc^8'
AES_IV = b'6oyZDr22E3ychjM%'
LOGIN_URL = "https://loginbp.common.ggbluefox.com/MajorLogin"
LIKE_URL = "https://client.ind.freefiremobile.com/LikeProfile"
PROFILE_URL = "https://client.ind.freefiremobile.com/GetPlayerPersonalShow"

def get_access_token_from_eat(eat_token):
    try:
        callback_url = f"https://api-otrss.garena.com/support/callback?access_token={eat_token}"
        response = requests.get(callback_url, allow_redirects=True, timeout=15)
        final_url = response.url
        parsed_url = urlparse(final_url)
        params = parse_qs(parsed_url.query)
        access_tokens = params.get('access_token')
        if access_tokens:
            return access_tokens[0]
        return None
    except:
        return None

def get_open_id_from_token(access_token):
    try:
        url = f"https://ffmconnect.live.gop.garenanow.com/oauth/token/inspect?token={access_token}"
        headers = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; Chrome/139.0.0.0 Mobile)",
            "Accept": "application/json",
        }
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        return {
            "uid": data.get("uid"),
            "open_id": data.get("open_id"),
            "platform": data.get("platform")
        }
    except:
        return None

def build_game_data(open_id, access_token, platform_type):
    game_data = my_pb2.GameData()
    game_data.timestamp = "2024-12-05 18:15:32"
    game_data.game_name = "free fire"
    game_data.game_version = 1
    game_data.version_code = "1.108.3"
    game_data.os_info = "Android OS 9 / API-28 (PI/rel.cjw.20220518.114133)"
    game_data.device_type = "Handheld"
    game_data.network_provider = "Verizon Wireless"
    game_data.connection_type = "WIFI"
    game_data.screen_width = 1280
    game_data.screen_height = 960
    game_data.dpi = "240"
    game_data.cpu_info = "ARMv7 VFPv3 NEON VMH | 2400 | 4"
    game_data.total_ram = 5951
    game_data.gpu_name = "Adreno (TM) 640"
    game_data.gpu_version = "OpenGL ES 3.0"
    game_data.user_id = "Google|74b585a9-0268-4ad3-8f36-ef41d2e53610"
    game_data.ip_address = "172.190.111.97"
    game_data.language = "en"
    game_data.open_id = open_id
    game_data.access_token = access_token
    game_data.platform_type = platform_type
    game_data.device_form_factor = "Handheld"
    game_data.device_model = "Asus ASUS_I005DA"
    game_data.field_60 = 32968
    game_data.field_61 = 29815
    game_data.field_62 = 2479
    game_data.field_63 = 914
    game_data.field_64 = 31213
    game_data.field_65 = 32968
    game_data.field_66 = 31213
    game_data.field_67 = 32968
    game_data.field_70 = 4
    game_data.field_73 = 2
    game_data.library_path = "/data/app/com.dts.freefireth-QPvBnTUhYWE-7DMZSOGdmA==/lib/arm"
    game_data.field_76 = 1
    game_data.apk_info = "5b892aaabd688e571f688053118a162b|/data/app/com.dts.freefireth-QPvBnTUhYWE-7DMZSOGdmA==/base.apk"
    game_data.field_78 = 6
    game_data.field_79 = 1
    game_data.os_architecture = "32"
    game_data.build_number = "2019117877"
    game_data.field_85 = 1
    game_data.graphics_backend = "OpenGLES2"
    game_data.max_texture_units = 16383
    game_data.rendering_api = 4
    game_data.encoded_field_89 = "\u0017T\u0011\u0017\u0002\b\u000eUMQ\bEZ\u0003@ZK;Z\u0002\u000eV\ri[QVi\u0003\ro\t\u0007e"
    game_data.field_92 = 9204
    game_data.marketplace = "3rd_party"
    game_data.encryption_key = "KqsHT2B4It60T/65PGR5PXwFxQkVjGNi+IMCK3CFBCBfrNpSUA1dZnjaT3HcYchlIFFL1ZJOg0cnulKCPGD3C3h1eFQ="
    game_data.total_storage = 111107
    game_data.field_97 = 1
    game_data.field_98 = 1
    game_data.field_99 = str(platform_type)
    game_data.field_100 = str(platform_type)
    return game_data

def encrypt_message(plaintext):
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    padded_message = pad(plaintext, AES.block_size)
    encrypted_message = cipher.encrypt(padded_message)
    return binascii.hexlify(encrypted_message).decode('utf-8')

def generate_jwt(access_token):
    user_data = get_open_id_from_token(access_token)
    if not user_data or not user_data.get("open_id"):
        return None, None

    open_id = user_data["open_id"]
    platform_type = user_data.get("platform", 4)
    uid = user_data.get("uid")

    game_data = build_game_data(open_id, access_token, platform_type)
    serialized_data = game_data.SerializeToString()
    encrypted_data_hex = encrypt_message(serialized_data)
    edata = bytes.fromhex(encrypted_data_hex)

    headers = {
        'Authorization': "Bearer",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB53",
        'Host': "loginbp.common.ggbluefox.com"
    }

    try:
        response = requests.post(LOGIN_URL, data=edata, headers=headers, verify=False)
        if response.status_code == 200:
            parsed = output_pb2.Garena_420()
            parsed.ParseFromString(response.content)
            response_str = str(parsed)
            if "token: " in response_str:
                token_result = response_str.split("token: ")[1].split("\n")[0].strip('"')
                return token_result, uid
    except:
        pass
    return None, None

def create_protobuf_message(user_id, region):
    message = like_pb2.like()
    message.uid = int(user_id)
    message.region = region
    return message.SerializeToString()

def create_uid_protobuf(uid):
    message = uid_generator_pb2.uid_generator()
    message.saturn_ = int(uid)
    message.garena = 1
    return message.SerializeToString()

def encrypt_uid(uid):
    protobuf_data = create_uid_protobuf(uid)
    encrypted_uid = encrypt_message(protobuf_data)
    return encrypted_uid

def get_profile_info(uid, token):
    encrypt = encrypt_uid(uid)
    edata = bytes.fromhex(encrypt)
    
    headers = {
        'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)",
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Authorization': f"Bearer {token}",
        'Content-Type': "application/x-www-form-urlencoded",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB53"
    }
    
    try:
        response = requests.post(PROFILE_URL, data=edata, headers=headers, verify=False)
        hex_data = response.content.hex()
        binary = bytes.fromhex(hex_data)
        items = like_count_pb2.Info()
        items.ParseFromString(binary)
        jsone = MessageToJson(items)
        data = json.loads(jsone)
        
        likes = data.get('AccountInfo', {}).get('Likes', 0)
        name = data.get('AccountInfo', {}).get('PlayerNickname', 'Unknown')
        uid = data.get('AccountInfo', {}).get('UID', 0)
        
        return {
            'likes': int(likes) if likes else 0,
            'name': str(name),
            'uid': int(uid)
        }
    except:
        return None

async def send_like_request(session, encrypted_uid, jwt_token, token_uid, i, target_uid):
    edata = bytes.fromhex(encrypted_uid)
    headers = {
        'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)",
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Authorization': f"Bearer {jwt_token}",
        'Content-Type': "application/x-www-form-urlencoded",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB53"
    }
    try:
        async with session.post(LIKE_URL, data=edata, headers=headers) as response:
            status = response.status
            if status == 200:
                print(f"[{i}] Success - Token UID: {token_uid} -> Target: {target_uid}")
                return 200
            else:
                print(f"[{i}] Failed - Token UID: {token_uid}")
                return status
    except:
        print(f"[{i}] Failed - Token UID: {token_uid}")
        return None

async def process_batch(jwt_data, target_uid, encrypted_uid):
    connector = aiohttp.TCPConnector(limit=50, limit_per_host=50)
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = []
        for i, data in enumerate(jwt_data, 1):
            task = asyncio.create_task(
                send_like_request(session, encrypted_uid, data['jwt'], data['uid'], i, target_uid)
            )
            tasks.append(task)
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return results

def convert_eat_batch(eat_tokens):
    access_tokens = []
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = []
        for eat_token in eat_tokens:
            future = executor.submit(get_access_token_from_eat, eat_token)
            futures.append(future)
        
        for future in futures:
            result = future.result()
            if result:
                access_tokens.append(result)
    return access_tokens

def generate_jwt_batch(access_tokens):
    jwt_data = []
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = []
        for token in access_tokens:
            future = executor.submit(generate_jwt, token)
            futures.append(future)
        
        for future in futures:
            jwt_token, uid = future.result()
            if jwt_token:
                jwt_data.append({'jwt': jwt_token, 'uid': uid})
    return jwt_data

async def main():
    target_uid = input("Enter target UID: ").strip()
    
    try:
        with open("aT.json", "r") as f:
            eat_tokens = json.load(f)
    except:
        print("Failed to load aT.json")
        return
    
    if not eat_tokens:
        print("No EAT tokens found in aT.json")
        return
    
    print(f"Total EAT tokens found: {len(eat_tokens)}")
    
    print("Converting EAT tokens to access tokens...")
    access_tokens = convert_eat_batch(eat_tokens)
    print(f"Converted: {len(access_tokens)}/{len(eat_tokens)}")
    
    if not access_tokens:
        print("No valid access tokens obtained")
        return
    
    print("Generating JWT tokens...")
    jwt_data = generate_jwt_batch(access_tokens)
    print(f"Generated: {len(jwt_data)}/{len(access_tokens)}")
    
    if not jwt_data:
        print("Failed to generate JWT tokens")
        return
    
    first_jwt = jwt_data[0]['jwt']
    before_profile = get_profile_info(target_uid, first_jwt)
    if before_profile:
        print(f"Player: {before_profile['name']}")
        print(f"Likes before: {before_profile['likes']}")
    else:
        print("Could not fetch initial profile")
        return
    
    protobuf_message = create_protobuf_message(target_uid, "IND")
    encrypted_uid = encrypt_message(protobuf_message)
    
    print(f"\nProcessing {len(jwt_data)} tokens to UID: {target_uid}\n")
    
    results = await process_batch(jwt_data, target_uid, encrypted_uid)
    
    success = sum(1 for r in results if r == 200)
    failed = len(results) - success
    
    print(f"\nChecking final likes...")
    last_jwt = jwt_data[-1]['jwt']
    after_profile = get_profile_info(target_uid, last_jwt)
    if after_profile:
        likes_given = after_profile['likes'] - before_profile['likes']
        print(f"\nPlayer: {after_profile['name']}")
        print(f"Likes before: {before_profile['likes']}")
        print(f"Likes after: {after_profile['likes']}")
        print(f"Likes given: {likes_given}")
    
    print(f"\nTotal: {success} success, {failed} failed")

if __name__ == '__main__':
    asyncio.run(main())